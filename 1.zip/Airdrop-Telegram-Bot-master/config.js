     // replace the value below with the Telegram token you receive from @BotFather
     var token = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
     // firebase config from console.firebase
     // Your web app's Firebase configuration
     var config = {
         apiKey: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
         authDomain: "XXXXXXXXXXX.firebaseapp.com",
         databaseURL: "https://XXXXXXXXX.firebaseio.com/",
         projectId: "XXXXXXXX",
         storageBucket: "XXXXXXXXXXXX.appspot.com",
         messagingSenderId: "XXXXXXXXXXXXX",
         appId: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
         measurementId: "X-XXXXXXXXX",
     };

     exports.token = token;
     exports.firebase_config = firebaseConfig;